from django.apps import AppConfig


class InferenceAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'inference_app'
